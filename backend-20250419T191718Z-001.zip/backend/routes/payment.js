const express = require('express');
const router = express.Router();

router.post('/process', (req, res) => {
  const { amount, method, bookingId } = req.body;
  
  console.log(`Shopner Biye Payment: ${amount} BDT via ${method} for booking ${bookingId}`);
  
  res.json({
    success: true,
    message: `Shopner Biye payment of ৳${amount} processed via ${method}`,
    transactionId: 'SHOPNER-' + Math.random().toString(36).substr(2, 8).toUpperCase()
  });
});

module.exports = router;