const Booking = require('../models/Booking');
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);

const createBooking = async (req, res) => {
  try {
    const { customerName, venueName, bookingDate } = req.body;
    const booking = new Booking({ customerName, venueName, bookingDate });
    await booking.save();
    res.status(201).json({ bookingId: booking._id });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

const createPayment = async (req, res) => {
  try {
    const { bookingId, amount } = req.body;
    const paymentIntent = await stripe.paymentIntents.create({
      amount: amount * 100,
      currency: 'usd',
      payment_method_types: ['card'],
    });
    const booking = await Booking.findByIdAndUpdate(
      bookingId,
      { paymentId: paymentIntent.id, paymentStatus: 'pending' },
      { new: true }
    );
    res.json({ clientSecret: paymentIntent.client_secret });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

const getBookings = async (req, res) => {
  try {
    const bookings = await Booking.find();
    res.json(bookings);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

module.exports = { createBooking, createPayment, getBookings };