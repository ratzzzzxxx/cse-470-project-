const mongoose = require('mongoose');

const bookingSchema = new mongoose.Schema({
  customerName: { type: String, required: true },
  venueName: { type: String, required: true },
  bookingDate: { type: Date, required: true },
  paymentStatus: { type: String, default: 'pending' },
  paymentId: { type: String },
});

module.exports = mongoose.model('Booking', bookingSchema);